package com.example.records;

import java.util.ArrayList;

public class Hall {
    public String hallName;
    public ArrayList<Person> residents;
    public ArrayList<Payment> payments;

    public Hall(String hallName) {
        this.hallName = hallName;
        this.residents = new ArrayList<>();
        this.payments = new ArrayList<>();
    }

    public String getHallName() {
        return hallName;
    }

    public ArrayList<Person> getResidents() {
        return residents;
    }

    public ArrayList<Payment> getPayments() {
        return payments;
    }

    public void addResident(Person resident) {
        residents.add(resident);
    }

    public void removeResident(Person resident) {
        residents.remove(resident);
    }

    public void addPayment(Payment payment) {
        payments.add(payment);
    }

    public void removePayment(Payment payment) {
        payments.remove(payment);
    }
    public String toString()
    {
        return " ___ HALL NAME: "+hallName;
    }
}
