package com.example.records;

import java.time.LocalDate;
import java.util.Date;

public class Person {
    public String name;
    public String gender;
    public LocalDate dateOfBirth;

    public int age;
    public String address;
    public String nationality;
    public LocalDate registrationDate;

    public Person(String name, String gender, LocalDate dateOfBirth, int age, String address, String nationality, LocalDate registrationDate) {
        this.name = name;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;

        this.age = age;
        this.address = address;
        this.nationality = nationality;
        this.registrationDate = registrationDate;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public int getAge() {
        return age;
    }

    public String getAddress() {
        return address;
    }

    public String getNationality() {
        return nationality;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public String toString()
    {
        return "NAME: "+name+" ___ GENDER: "+gender+" ___ AGE"+age+" ___ DOB: "+dateOfBirth+" ___ ADDRESS: "+address+" ___ NATIONALITY: "+nationality+" ___ DOR: "+registrationDate;
    }
}

