package com.example.records;
import java.time.LocalDate;
import java.util.Date;


public class Student extends Person {
    public String studentID;

    public Student(String name, String gender, LocalDate dateOfBirth, int age, String address, String nationality, LocalDate registrationDate, String studentID) {
        super(name, gender, dateOfBirth,age, address, nationality, registrationDate);
        this.studentID = studentID;
    }

    public String getStudentID() {
        return studentID;
    }
    public String toString()
    {
        return super.toString()+" ___ ID: "+studentID;
    }
}
