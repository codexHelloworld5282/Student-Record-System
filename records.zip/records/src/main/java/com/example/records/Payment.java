package com.example.records;

import java.util.Date;

public class Payment {
    public String amount;

    public Payment(String amount) {
        this.amount = amount;

    }

    public String toString()
    {
        return " ___ AMOUNT: "+amount;
    }
    public String getAmount() {
        return amount;
    }

}
