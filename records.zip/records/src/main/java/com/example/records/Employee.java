package com.example.records;

import java.time.LocalDate;
import java.util.Date;

public class Employee extends Person {
    public String employeeID;

    public Employee(String name, String gender, LocalDate dateOfBirth, int age, String address, String nationality, LocalDate registrationDate, String employeeID) {
        super(name, gender, dateOfBirth, age, address, nationality, registrationDate);
        this.employeeID = employeeID;
    }

    public String getEmployeeID() {
        return employeeID;
    }
    public String toString()
    {
        return super.toString()+" ___ ID: "+employeeID;
    }
}
