package com.example.records;

import java.util.ArrayList;

public class Store {
    public ArrayList<Person> people;

    public Store() {
        this.people = new ArrayList<>();
    }

    public void addPerson(Person person) {
        people.add(person);
    }

    public void removePerson(Person person) {
        people.remove(person);
    }

    public ArrayList<Person> getPeople() {
        return people;
    }
}
